/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prestamos;

import java.util.Scanner;

/**
 *
 * @author PERSONAL
 */
public class Personal {
    public String motivo;
    
    Scanner in = new Scanner(System.in);
    
    public Personal(){}
    
    public void AgregarDatos() {
        System.out.println("Motivo: ");
        this.motivo = in.next();
    }

}
