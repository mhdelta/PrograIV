/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prestamos;

import static java.lang.System.in;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author PERSONAL
 */
public class Prestamos {

    public double monto_a_prestar;
    public float interes;
    public int numero_cuotas;
    public Cliente cliente;
    public Personal personal;
    public Prendario prendario;
    public Hipotecario hipotecario;

    ArrayList validaciones = new ArrayList();
    ArrayList tipo_prestamo = new ArrayList();

    public Prestamos() {
        this.tipo_prestamo.add(0);
        this.tipo_prestamo.add(0);
        this.tipo_prestamo.add(0);

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);

        int fin = 0;

        while (fin != 1) {

            System.out.println("Prestamos..");

            System.out.println("[1]. Generar Prestamo");
            System.out.println("[2]. Remover validaciones");
            System.out.println("[0]. Salir");

            System.out.println("Elija una opción: ");
            int op = in.nextInt();

            switch (op) {
                case 1:
                    Cliente cliente = new Cliente();
                    cliente.AgregarDatos();
                    Prestamos prestamo = new Prestamos();
                    prestamo.cliente = cliente;
                    prestamo.SeleccionarTipoPrestamo();
                    prestamo.AgregarInfoPrestamo();
                    if (prestamo.ValidarPrestamo()) {
                        prestamo.MostrarDetallesPrestamo();
                    } else {
                        fin = 1;
                    }
                    
                    break;
                case 2:
                    System.out.println("Numero de la validacion a remover");
                    int val = in.nextInt();
                    System.out.println("Eliminación correcta");
                    break;

                case 0:
                    fin = 1;
                    break;
            }
        }

    }

    public void SeleccionarTipoPrestamo() {
        Scanner in = new Scanner(System.in);
        int fin = 0;
        while (fin != 1) {
            System.out.println("[1]. Agregar categoria de prestamo");
            System.out.println("[0]. Salir");
            int op;
            op = in.nextInt();
            switch (op) {
                case 1:
                    System.out.println("[1]. Personal");
                    System.out.println("[2]. Prendario para autos");
                    System.out.println("[3]. Hipotecarios");
                    int op2;
                    op2 = in.nextInt();

                    switch (op2) {
                        case 1:
                            this.tipo_prestamo.set(0, 1);
                            this.personal = new Personal();
                            this.personal.AgregarDatos();

                            break;
                        case 2:
                            this.tipo_prestamo.set(1, 1);
                            this.prendario = new Prendario();
                            this.prendario.AgregarDatos();
                            break;
                        case 3:
                            this.tipo_prestamo.set(2, 1);
                            this.hipotecario = new Hipotecario();
                            this.hipotecario.AgregarDatos();
                            break;

                        default:
                            break;
                    }
                    break;
                case 0:
                    fin = 1;
                    break;
            }
        }
    }

    public void AgregarInfoPrestamo() {
        Scanner in = new Scanner(System.in);
        System.out.println("Tasa de interes: ");
        this.interes = in.nextFloat();
        System.out.println("Monto a prestar: ");
        this.monto_a_prestar = in.nextDouble();
        System.out.println("Número de cuotas: ");
        this.numero_cuotas = in.nextInt();
    }

    public boolean ValidarPrestamo() {
        boolean result = true;
        if (Objects.equals(this.tipo_prestamo.get(0), 1)) {
            if (this.monto_a_prestar > 10000) {
                System.out.println("Los montos para prestamos personales no pueden exceder los 10.000");
                System.out.println("Saliendo de la app..");
                result = false;
            }
        }
        if (Objects.equals(this.tipo_prestamo.get(1), 1)) {
            if (this.monto_a_prestar < 20000 || this.monto_a_prestar > 40000) {
                System.out.println("Los montos PRENDARIOS O DE AUTOS DEBEN ESTAR ENTRE LOS $20.000 Y LOS $40.000");
                System.out.println("Saliendo de la app..");
                result = false;
            }
            if (this.monto_a_prestar > this.prendario.valor * 0.4) {
                System.out.println("El valor del monto no debe superar el 40% del bien a comprar");
                System.out.println("Saliendo de la app..");
                result = false;
            }
        }
        if (Objects.equals(this.tipo_prestamo.get(2), 1)) {
            if (this.monto_a_prestar > 150000) {
                System.out.println("Los montos hipotecários deben ser superiores a loas $150.000");
                System.out.println("Saliendo de la app..");
                result = false;
            }
            if (this.monto_a_prestar > this.hipotecario.valor * 0.4) {
                System.out.println("El valor del monto no debe superar el 40% del bien a comprar");
                System.out.println("Saliendo de la app..");
                result = false;
            }
        }
        if ((this.monto_a_prestar * (this.interes/100)) / this.numero_cuotas > 10000) {
            System.out.println("Los montos por cada cuota no deben ser superiores a los $10.000");
            System.out.println("Saliendo de la app..");
            result = false;
        }

        if (this.interes > 15) {
            System.out.println("El interés no debe superar el 15% [0.15]");
            System.out.println("Saliendo de la app..");
            result = false;
        }

        if (this.numero_cuotas > 60) {
            System.out.println("No deben existir más de 60 cuotas");
            System.out.println("Saliendo de la app..");
            result = false;
        }

        return result;
    }

    public void MostrarDetallesPrestamo() {
        System.out.println("==================================");
        System.out.println("Datos del cliente");
        System.out.println("nombre: " + this.cliente.nombre);
        System.out.println("apellido: " + this.cliente.apellido);
        System.out.println("dirección: " + this.cliente.direccion);
        System.out.println("==================================");
        System.out.println("Datos del prestamo");
        System.out.println("interes: " + this.interes);
        System.out.println("Monto a prestar: " + this.monto_a_prestar);
        System.out.println("Número de cuotas: " + this.numero_cuotas);
        System.out.println("==================================");
        if (Objects.equals(this.tipo_prestamo.get(0), 1)) {
            System.out.println("Motivo: " + this.personal.motivo);
        }
        if (Objects.equals(this.tipo_prestamo.get(1), 1)) {
            System.out.println("Valor: "+ this.prendario.valor);
            System.out.println("Marca: "+ this.prendario.marca);
        }
        
        

    }

}
