/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prestamos;

import java.util.Scanner;

/**
 *
 * @author PERSONAL
 */
public class Hipotecario {
    public double metros;
    public double valor;
    public String direccion;

    
    Scanner in = new Scanner(System.in);
    
    public Hipotecario(){}

    public void AgregarDatos() {
        System.out.println("Valor: ");
        this.valor = in.nextDouble();
        
        System.out.println("Metros cuadrados: ");
        this.metros = in.nextDouble();
        
        System.out.println("Direccion: ");
        this.direccion = in.next();
        
        
    }

}
