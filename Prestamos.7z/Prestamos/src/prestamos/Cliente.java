package prestamos;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;

/**
 *
 * @author PERSONAL
 */
public class Cliente {

    Scanner in = new Scanner(System.in);

    public String nombre;
    public String apellido;
    public String direccion;
    
    public Cliente(){}

    public void AgregarDatos() {
        System.out.println("Nombre: ");
        this.nombre = in.next();
        System.out.println("Apellido: ");
        this.apellido = in.next();
        System.out.println("Dirección: ");
        this.direccion = in.next();
    }
}
