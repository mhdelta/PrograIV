/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prestamos;

import java.util.Scanner;

/**
 *
 * @author PERSONAL
 */
public class Prendario {

    public double valor;
    public String patente;
    public String año;
    public String marca;
    public String modelo;
    
    Scanner in = new Scanner(System.in);

    public Prendario(){}
    
    public void AgregarDatos() {
        System.out.println("Valor: ");
        this.valor = in.nextDouble();
        
        System.out.println("Patente: ");
        this.patente = in.next();
        
        System.out.println("Año: ");
        this.año = in.next();
        
        System.out.println("Modelo: ");
        this.modelo = in.next();
        
        System.out.println("Marca: ");
        this.marca = in.next();
        
        
    }

}
