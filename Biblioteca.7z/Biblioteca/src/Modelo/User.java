/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author PERSONAL
 */
public class User {
    public String nombre;
    public int deuda;
    
    User(String nombre){
        this.nombre = nombre;
    }
    
    public void Reservar(){}    
    public void Prestar(){}
}


