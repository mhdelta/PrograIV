/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package garaje;

import java.util.*;


/**
 *
 * @author mhdelta
 */
public class reparacion{
    public String informacion;
    public int km_al_reparar;
    
    public reparacion(){
        this.informacion = "";
        this.km_al_reparar = 0;
    }
}
